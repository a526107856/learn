package cn.edu.sylu.OnlinePha.pager;

public class PageConstants {
	public static final int BOOK_PAGE_SIZE = 12;//图书每页记录数
	public static final int ORDER_PAGE_SIZE = 8;//订单每页记录数
	public static final int MEDICINE_PAGE_SIZE = 12;//药品每页记录数
}
