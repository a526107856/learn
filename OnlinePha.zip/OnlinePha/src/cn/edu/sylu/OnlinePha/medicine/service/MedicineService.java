package cn.edu.sylu.OnlinePha.medicine.service;

import java.sql.SQLException;

import cn.edu.sylu.OnlinePha.medicine.dao.MedicineDao;
import cn.edu.sylu.OnlinePha.medicine.domain.Medicine;
import cn.edu.sylu.OnlinePha.pager.PageBean;

public class MedicineService {

	private MedicineDao medicineDao = new MedicineDao();

	/**
	 * 添加药品
	 * 
	 * @param medicine
	 */
	public void add(Medicine medicine) {
		try {
			medicineDao.add(medicine);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 返回当前分类下商品个数
	 * 
	 * @param cid
	 * @return
	 */
	public int findMedicineCountByCategory(String cid) {
		try {
			return medicineDao.findMedicineCountByCategory(cid);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 查询商品详细信息
	 * 
	 * @param bid
	 * @return
	 */
	public Medicine load(String bid) {
		try {
			return medicineDao.findByBid(bid);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 按分类查
	 * 
	 * @param cid
	 * @param pc
	 * @return
	 */
	public PageBean<Medicine> findByCategory(String cid, int pc) {
		try {
			return medicineDao.findByCategory(cid, pc);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 按商品名查
	 * 
	 * @param bname
	 * @param pc
	 * @return
	 */
	public PageBean<Medicine> findByMedName(String medName, int pc) {
		try {
			return medicineDao.findByMedName(medName, pc);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 按作者查
	 * 
	 * @param author
	 * @param pc
	 * @return
	 */
	/*
	 * public PageBean<Book> findByAuthor(String author, int pc) { try { return
	 * bookDao.findByAuthor(author, pc); } catch (SQLException e) { throw new
	 * RuntimeException(e); } }
	 */

	/**
	 * 按生产厂商查
	 * 
	 * @param factory
	 * @param pc
	 * @return
	 */
	public PageBean<Medicine> findByFactory(String factory, int pc) {
		try {
			return medicineDao.findByFactory(factory, pc);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 多条件组合查询
	 * 
	 * @param criteria
	 * @param pc
	 * @return
	 */
	public PageBean<Medicine> findByCombination(Medicine criteria, int pc) {
		try {
			return medicineDao.findByCombination(criteria, pc);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 修改药品
	 * @param book
	 */
	public void edit(Medicine medicine) {
		try {
			medicineDao.edit(medicine);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * 删除药品
	 * @param bid
	 */
	public void delete(String bid) {
		try {
			medicineDao.delete(bid);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
