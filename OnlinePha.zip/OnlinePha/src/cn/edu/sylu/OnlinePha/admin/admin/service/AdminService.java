package cn.edu.sylu.OnlinePha.admin.admin.service;

import java.sql.SQLException;

import cn.edu.sylu.OnlinePha.admin.admin.dao.AdminDao;
import cn.edu.sylu.OnlinePha.admin.admin.domain.Admin;

public class AdminService {
	private AdminDao adminDao = new AdminDao();
	
	/**
	 * 登录功能
	 * @param admin
	 * @return
	 */
	public Admin login(Admin admin) {
		try {
			return adminDao.find(admin.getAdminname(), admin.getAdminpwd());
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
}
