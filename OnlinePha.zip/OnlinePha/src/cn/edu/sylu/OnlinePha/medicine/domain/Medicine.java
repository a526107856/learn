package cn.edu.sylu.OnlinePha.medicine.domain;

import cn.edu.sylu.OnlinePha.category.domain.Category;

public class Medicine {

	private String bid;// 主键
	private String medName;// 药品名
	private String composition;// 成分
	private String character;// 性状
	private String useInfo;// 功能主治
	private String spec;// 规格
	private String takingInstr;// 用法用量
	private String adverseReaction;// 不良反应
	private String taboo;// 禁忌
	private String needAttention;// 注意事项
	private String drugInteraction;// 药物相互作用
	private String storage;// 贮藏
	private String packaging;// 包装
	private String medPeriod;// 保质期
	private String approvalNum;// 批准文号
	private String medFactory;// 制药厂
	private double price;// 定价
	private double currPrice;// 当前价格
	private double discount;// 折扣
	private String image_w;// 大图路径
	private String image_b;// 小图路径

	private Category category;// 所属分类

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getMedName() {
		return medName;
	}

	public void setMedName(String medName) {
		this.medName = medName;
	}

	public String getComposition() {
		return composition;
	}

	public void setComposition(String composition) {
		this.composition = composition;
	}

	public String getCharacter() {
		return character;
	}

	public void setCharacter(String character) {
		this.character = character;
	}

	public String getUseInfo() {
		return useInfo;
	}

	public void setUseInfo(String useInfo) {
		this.useInfo = useInfo;
	}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getTakingInstr() {
		return takingInstr;
	}

	public void setTakingInstr(String takingInstr) {
		this.takingInstr = takingInstr;
	}

	public String getAdverseReaction() {
		return adverseReaction;
	}

	public void setAdverseReaction(String adverseReaction) {
		this.adverseReaction = adverseReaction;
	}

	public String getTaboo() {
		return taboo;
	}

	public void setTaboo(String taboo) {
		this.taboo = taboo;
	}

	public String getNeedAttention() {
		return needAttention;
	}

	public void setNeedAttention(String needAttention) {
		this.needAttention = needAttention;
	}

	public String getDrugInteraction() {
		return drugInteraction;
	}

	public void setDrugInteraction(String drugInteraction) {
		this.drugInteraction = drugInteraction;
	}
	
	public String getStorage() {
		return storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public String getPackaging() {
		return packaging;
	}

	public void setPackaging(String packaging) {
		this.packaging = packaging;
	}

	public String getMedPeriod() {
		return medPeriod;
	}

	public void setMedPeriod(String medPeriod) {
		this.medPeriod = medPeriod;
	}

	public String getApprovalNum() {
		return approvalNum;
	}

	public void setApprovalNum(String approvalNum) {
		this.approvalNum = approvalNum;
	}

	public String getMedFactory() {
		return medFactory;
	}

	public void setMedFactory(String medFactory) {
		this.medFactory = medFactory;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getCurrPrice() {
		return currPrice;
	}

	public void setCurrPrice(double currPrice) {
		this.currPrice = currPrice;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public String getImage_w() {
		return image_w;
	}

	public void setImage_w(String image_w) {
		this.image_w = image_w;
	}

	public String getImage_b() {
		return image_b;
	}

	public void setImage_b(String image_b) {
		this.image_b = image_b;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Medicine [bid=" + bid + ", medName=" + medName
				+ ", composition=" + composition + ", character=" + character
				+ ", useInfo=" + useInfo + ", spec=" + spec + ", takingInstr="
				+ takingInstr + ", adverseReaction=" + adverseReaction
				+ ", taboo=" + taboo + ", needAttention=" + needAttention
				+ ", drugInteraction=" + drugInteraction + ", storage="
				+ storage + ", packaging=" + packaging + ", medPeriod="
				+ medPeriod + ", approvalNum=" + approvalNum + ", medFactory="
				+ medFactory + ", price=" + price + ", currPrice=" + currPrice
				+ ", discount=" + discount + ", image_w=" + image_w
				+ ", image_b=" + image_b + ", category=" + category + "]";
	}

}
